/**
 * ECOCITY PIXEL ART — INTERFACE DA TELEVISÃO (TELA PRINCIPAL)
 * Gerencia conexão WebSocket, recebimento de comandos do celular e exibição em tempo real.
 */

document.addEventListener('DOMContentLoaded', () => {
  const canvasId = 'pixel-canvas';
  const engine = new GameEngine(canvasId);
  engine.start();

  // Inicializa motor de sincronização com papel 'tv'
  const sync = new VidaSyncEngine({ role: 'tv' });

  const qrCodeContainer = document.getElementById('qrcode-container');
  const sessionCodeSpan = document.getElementById('session-code');
  const activeVisitorBadge = document.getElementById('active-visitor-badge');
  const banner = document.getElementById('emergency-banner');
  const dismissAlertBtn = document.getElementById('dismiss-alert-btn');
  const startFloodBtn = document.getElementById('start-flood-btn');
  const startFactionBtn = document.getElementById('start-faction-btn');

  if (sessionCodeSpan) {
    sessionCodeSpan.innerText = sync.sessionId;
  }

  // Gera QR Code para conexão do celular
  if (qrCodeContainer && window.QRCode) {
    const mobileUrl = `${window.location.origin}/prototipo-pixel-art/controle.html?session=${sync.sessionId}`;
    new QRCode(qrCodeContainer, {
      text: mobileUrl,
      width: 120,
      height: 120,
      colorDark: '#00ff88',
      colorLight: '#161e2e',
      correctLevel: QRCode.CorrectLevel.M
    });
  }

  // Eventos de Sincronização
  sync.on('visitor_connected', (visitor) => {
    if (activeVisitorBadge) {
      activeVisitorBadge.innerText = `Visitante Ativo: ${visitor.nome} (${visitor.modo || 'Individual'})`;
      activeVisitorBadge.style.display = 'block';
    }
  });

  sync.on('visitor_disconnected', () => {
    if (activeVisitorBadge) {
      activeVisitorBadge.innerText = 'Stand Disponível';
      activeVisitorBadge.style.display = 'none';
    }
  });

  sync.on('player_action', (payload) => {
    if (payload && payload.actionId) {
      engine.scenarioManager.applyAction(payload.actionId);
      if (window.soundManager) window.soundManager.playSuccess();
    }
  });

  // Botões de Início de Cenário na TV (para testes ou controle direto)
  if (dismissAlertBtn) {
    dismissAlertBtn.addEventListener('click', () => {
      banner.style.display = 'none';
      engine.scenarioManager.startSimulation();
      if (window.soundManager) window.soundManager.playClick();
    });
  }

  if (startFloodBtn) {
    startFloodBtn.addEventListener('click', () => {
      engine.scenarioManager.loadScenario('inundacao');
      if (window.soundManager) window.soundManager.playClick();
    });
  }

  if (startFactionBtn) {
    startFactionBtn.addEventListener('click', () => {
      engine.scenarioManager.loadScenario('guerra_faccoes');
      if (window.soundManager) window.soundManager.playClick();
    });
  }
});
