/**
 * ECOCITY PIXEL ART — INTERFACE DO CELULAR (CONTROLE DO VISITANTE)
 */

document.addEventListener('DOMContentLoaded', () => {
  const urlParams = new URLSearchParams(window.location.search);
  const sessionId = urlParams.get('session') || 'VIDA-DEMO';

  const sync = new VidaSyncEngine({ role: 'mobile', sessionId });

  const loginScreen = document.getElementById('login-screen');
  const controlScreen = document.getElementById('control-screen');
  const playerNameInput = document.getElementById('player-name');
  const gameModeSelect = document.getElementById('game-mode');
  const joinBtn = document.getElementById('join-btn');
  const actionButtonsContainer = document.getElementById('action-buttons');
  const playerRoleBadge = document.getElementById('player-role-badge');
  const connectionStatus = document.getElementById('connection-status');

  sync.on('connection_status', (status) => {
    if (connectionStatus) {
      connectionStatus.innerText = status.connected ? '🟢 Conectado à TV' : '🔴 Reconectando...';
      connectionStatus.style.color = status.connected ? '#00ff88' : '#ff3366';
    }
  });

  if (joinBtn) {
    joinBtn.addEventListener('click', () => {
      const nome = playerNameInput.value.trim() || 'Visitante Carioca';
      const modo = gameModeSelect.value; // 'individual', 'coop_p1', 'coop_p2'

      if (window.soundManager) window.soundManager.playClick();

      sync.send('VISITOR_JOIN_REQUEST', {
        visitor: { nome, modo }
      });

      loginScreen.style.display = 'none';
      controlScreen.style.display = 'block';
      if (playerRoleBadge) {
        playerRoleBadge.innerText = `Jogador: ${nome} [${modo.toUpperCase()}]`;
      }

      renderActionButtons(modo, sync);
    });
  }

  function renderActionButtons(modo, syncEngine) {
    if (!actionButtonsContainer) return;
    actionButtonsContainer.innerHTML = '';

    const actions = [];
    if (modo === 'individual' || modo === 'coop_p1') {
      actions.push(
        { id: 'p1_shelter', title: 'Abrir Abrigos', desc: 'Instala abrigos seguros' },
        { id: 'p1_routes', title: 'Rotas de Fuga', desc: 'Desvia tráfego urbano' },
        { id: 'p1_resources', title: 'Distribuir Suprimentos', desc: 'Água e kits de emergência' }
      );
    }
    if (modo === 'individual' || modo === 'coop_p2') {
      actions.push(
        { id: 'p2_teams', title: 'Equipes de Resgate', desc: 'Paramédicos e apoio' },
        { id: 'p2_health', title: 'Priorizar Hospitais', desc: 'Atendimento médico urgente' },
        { id: 'p2_env', title: 'Drenagem & Meio Ambiente', desc: 'Controle de alagamentos' }
      );
    }

    actions.forEach(action => {
      const btn = document.createElement('button');
      btn.className = 'pixel-btn';
      btn.style.width = '100%';
      btn.style.marginBottom = '12px';
      btn.style.textAlign = 'left';
      btn.innerHTML = `<strong>${action.title}</strong><br><span style="font-size:8px; color:var(--px-muted);">${action.desc}</span>`;
      btn.addEventListener('click', () => {
        if (window.soundManager) window.soundManager.playClick();
        syncEngine.send('player_action', { actionId: action.id });

        // Feedback tátil visual
        btn.style.borderColor = 'var(--px-accent)';
        setTimeout(() => { btn.style.borderColor = 'var(--px-border)'; }, 300);
      });
      actionButtonsContainer.appendChild(btn);
    });
  }
});
