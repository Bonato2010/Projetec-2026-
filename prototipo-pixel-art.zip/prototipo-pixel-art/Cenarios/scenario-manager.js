/**
 * ECOCITY PIXEL ART — GERENCIADOR DE CENÁRIOS & OCORRÊNCIAS
 */

class ScenarioManager {
  constructor(options = {}) {
    this.currentScenario = null;
    this.simulationState = 'normal'; // 'normal', 'alert', 'active', 'ended'
    this.elapsedTime = 0;
    this.floodLevel = 0;
    this.metrics = {
      safety: 85,
      health: 90,
      infrastructure: 88,
      environment: 82,
      resources: 95
    };
    this.onUpdateCallback = options.onUpdate || (() => {});
    this.onAlertCallback = options.onAlert || (() => {});
  }

  loadScenario(scenarioId) {
    // Carrega cenário escolhido ou aleatório
    this.simulationState = 'alert';
    this.elapsedTime = 0;
    this.floodLevel = 0;

    if (scenarioId === 'inundacao') {
      this.currentScenario = {
        id: 'inundacao',
        title: 'INUNDAÇÃO SEVERA',
        subtitle: 'Temporal intenso na região metropolitana',
        description: 'Frente fria estacionária provoca acumulados extremos de chuva. Risco de alagamentos nas vias principais e encostas.',
        type: 'flood'
      };
    } else {
      this.currentScenario = {
        id: 'guerra_faccoes',
        title: 'GUERRA DE FACÇÕES',
        subtitle: 'Alerta máximo de segurança pública',
        description: 'Uma região da cidade entrou em estado de alerta. Serviços essenciais podem ser comprometidos. Inicie os protocolos de resposta.',
        type: 'security'
      };
    }

    this.onAlertCallback(this.currentScenario);
  }

  startSimulation() {
    this.simulationState = 'active';
  }

  update(delta) {
    if (this.simulationState !== 'active') return;

    this.elapsedTime += delta;

    // Evolução progressiva para inundação
    if (this.currentScenario && this.currentScenario.type === 'flood') {
      if (this.elapsedTime > 10 && this.elapsedTime < 30) {
        this.floodLevel = 1; // Céu nublado e chuva leve
        this.metrics.environment = Math.max(40, this.metrics.environment - 0.05);
      } else if (this.elapsedTime >= 30 && this.elapsedTime < 70) {
        this.floodLevel = 2; // Chuva intensa
        this.metrics.infrastructure = Math.max(30, this.metrics.infrastructure - 0.1);
      } else if (this.elapsedTime >= 70) {
        this.floodLevel = 3; // Alagamento total das ruas
        this.metrics.safety = Math.max(30, this.metrics.safety - 0.08);
        this.metrics.health = Math.max(30, this.metrics.health - 0.05);
      }
    } else if (this.currentScenario && this.currentScenario.type === 'security') {
      // Degradação gradual se não houver intervenção
      if (this.elapsedTime > 20) {
        this.metrics.safety = Math.max(20, this.metrics.safety - 0.05);
      }
    }

    this.onUpdateCallback({
      elapsedTime: this.elapsedTime,
      floodLevel: this.floodLevel,
      metrics: this.metrics,
      state: this.simulationState
    });
  }

  applyAction(actionId) {
    if (actionId === 'p1_shelter') {
      this.metrics.safety = Math.min(100, this.metrics.safety + 15);
      this.metrics.resources = Math.max(0, this.metrics.resources - 10);
    } else if (actionId === 'p1_routes') {
      this.metrics.infrastructure = Math.min(100, this.metrics.infrastructure + 15);
    } else if (actionId === 'p1_resources') {
      this.metrics.resources = Math.min(100, this.metrics.resources + 20);
      this.metrics.health = Math.min(100, this.metrics.health + 10);
    } else if (actionId === 'p2_teams') {
      this.metrics.health = Math.min(100, this.metrics.health + 20);
      this.metrics.safety = Math.min(100, this.metrics.safety + 10);
    } else if (actionId === 'p2_health') {
      this.metrics.health = Math.min(100, this.metrics.health + 25);
      this.metrics.resources = Math.max(0, this.metrics.resources - 15);
    } else if (actionId === 'p2_env') {
      this.metrics.environment = Math.min(100, this.metrics.environment + 20);
      this.metrics.infrastructure = Math.min(100, this.metrics.infrastructure + 10);
      if (this.floodLevel > 0) {
        this.floodLevel = Math.max(0, this.floodLevel - 1);
      }
    }

    this.onUpdateCallback({
      elapsedTime: this.elapsedTime,
      floodLevel: this.floodLevel,
      metrics: this.metrics,
      state: this.simulationState
    });
  }

  getScore() {
    const values = Object.values(this.metrics);
    const avg = values.reduce((a, b) => a + b, 0) / values.length;
    return avg.toFixed(1);
  }
}

window.ScenarioManager = ScenarioManager;
