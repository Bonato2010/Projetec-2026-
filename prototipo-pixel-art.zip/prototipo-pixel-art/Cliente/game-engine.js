/**
 * ECOCITY PIXEL ART — MOTOR DO CLIENTE (CANVAS 2D)
 */

class GameEngine {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas.getContext('2d');
    this.width = window.innerWidth;
    this.height = window.innerHeight;
    this.canvas.width = this.width;
    this.canvas.height = this.height;

    this.scenarioManager = new ScenarioManager({
      onUpdate: (state) => this.handleStateUpdate(state),
      onAlert: (scenario) => this.handleAlert(scenario)
    });

    this.vehicles = [
      { x: 100, speed: 2.5, type: 'carRed' },
      { x: 450, speed: 3.0, type: 'bus' },
      { x: 800, speed: 2.0, type: 'carBlue' },
      { x: 1200, speed: 3.5, type: 'police' }
    ];

    this.citizens = [
      { x: 200, speed: 1.0, anim: 0 },
      { x: 500, speed: 0.8, anim: 1 },
      { x: 900, speed: 1.2, anim: 2 }
    ];

    this.animFrame = 0;
    this.isRunning = false;

    window.addEventListener('resize', () => {
      this.width = window.innerWidth;
      this.height = window.innerHeight;
      this.canvas.width = this.width;
      this.canvas.height = this.height;
    });
  }

  start() {
    this.isRunning = true;
    this.lastTime = performance.now();
    requestAnimationFrame((t) => this.loop(t));
  }

  loop(currentTime) {
    if (!this.isRunning) return;
    const delta = (currentTime - this.lastTime) / 1000;
    this.lastTime = currentTime;
    this.animFrame++;

    this.update(delta);
    this.render();

    requestAnimationFrame((t) => this.loop(t));
  }

  update(delta) {
    this.scenarioManager.update(delta);

    // Movimentação de veículos
    this.vehicles.forEach(v => {
      v.x += v.speed;
      if (v.x > this.width + 100) v.x = -150;
    });

    // Movimentação de cidadãos (reduzida se houver alerta severo)
    const speedMultiplier = this.scenarioManager.simulationState === 'active' ? 1.0 : 0.5;
    this.citizens.forEach(c => {
      c.x += c.speed * speedMultiplier;
      c.anim += 0.2;
      if (c.x > this.width + 50) c.x = -50;
    });
  }

  render() {
    const ctx = this.ctx;
    const width = this.width;
    const height = this.height;
    const scenarioState = this.scenarioManager.currentScenario;
    const floodLevel = this.scenarioManager.floodLevel;

    // 1. Fundo (Céu e Montanhas)
    const timeOfDay = (scenarioState && scenarioState.type === 'flood' && floodLevel > 0) ? 'storm' : 'day';
    window.spriteAtlas.drawCityBackground(ctx, width, height, timeOfDay, floodLevel);

    // 2. Prédios da Cidade
    window.spriteAtlas.drawBuildings(ctx, 40, height - 220, width - 80, height);

    // 3. Ruas e Calçadas
    window.spriteAtlas.drawStreetAndSidewalk(ctx, width, height, floodLevel);

    // 4. Veículos na Rua
    const streetY = height - 165;
    this.vehicles.forEach(v => {
      window.spriteAtlas.drawVehicle(ctx, v.x, streetY, v.type);
    });

    // 5. Cidadãos nas Calçadas
    const sidewalkTopY = height - 220;
    const sidewalkBottomY = height - 70;
    this.citizens.forEach((c, idx) => {
      const sy = idx % 2 === 0 ? sidewalkTopY : sidewalkBottomY;
      window.spriteAtlas.drawCitizen(ctx, c.x, sy, c.anim);
    });

    // 6. Efeito de Chuva se inundação ativa
    if (scenarioState && scenarioState.type === 'flood' && floodLevel > 0) {
      window.spriteAtlas.drawRain(ctx, width, height);
    }
  }

  handleAlert(scenario) {
    if (window.soundManager) window.soundManager.playAlertSiren();
    const banner = document.getElementById('emergency-banner');
    const titleEl = document.getElementById('alert-title');
    const descEl = document.getElementById('alert-desc');

    if (banner && titleEl && descEl) {
      titleEl.innerText = `ALERTA DE EMERGÊNCIA: ${scenario.title}`;
      descEl.innerText = scenario.description;
      banner.style.display = 'block';
    }
  }

  handleStateUpdate(state) {
    // Atualiza indicadores visuais na TV
    ['safety', 'health', 'infrastructure', 'environment', 'resources'].forEach(metric => {
      const fillEl = document.getElementById(`meter-${metric}`);
      const valEl = document.getElementById(`val-${metric}`);
      if (fillEl && valEl) {
        const val = Math.round(state.metrics[metric]);
        fillEl.style.width = `${val}%`;
        valEl.innerText = `${val}%`;
      }
    });
  }
}

window.GameEngine = GameEngine;
